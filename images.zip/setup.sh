#!/bin/bash

# ============================================
# Setup Nginx Reverse Proxy + SSL
# Untuk Domain: images.azxpedia.my.id
# ============================================

set -e  # Stop jika ada error

echo "========================================="
echo "  Setup Nginx + SSL untuk ImageHost"
echo "  Domain: images.azxpedia.my.id"
echo "========================================="
echo ""

# ============================================
# Cek apakah domain sudah pointing ke server
# ============================================
echo "🔍 Cek DNS domain..."
DOMAIN="images.azxpedia.my.id"
SERVER_IP=$(curl -s ifconfig.me)

if ping -c 1 $DOMAIN &> /dev/null; then
    echo "✅ Domain $DOMAIN terdeteksi"
    DOMAIN_IP=$(dig +short $DOMAIN | head -1)
    if [ "$DOMAIN_IP" = "$SERVER_IP" ]; then
        echo "✅ Domain sudah pointing ke server ini ($SERVER_IP)"
    else
        echo "⚠️  Domain pointing ke $DOMAIN_IP, tapi server IP adalah $SERVER_IP"
        echo "⚠️  Pastikan DNS sudah diupdate ke IP: $SERVER_IP"
        echo ""
        read -p "Lanjutkan tetap? (y/n): " -n 1 -r
        echo ""
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
else
    echo "⚠️  Domain $DOMAIN tidak terdeteksi"
    echo "⚠️  Pastikan DNS sudah diatur dan propagate"
    echo ""
    read -p "Lanjutkan tetap? (y/n): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo ""

# ============================================
# 4. Setup Nginx sebagai Reverse Proxy
# ============================================

echo "========================================="
echo "  4. Setup Nginx sebagai Reverse Proxy"
echo "========================================="

# Cek Nginx
if ! command -v nginx &> /dev/null; then
    echo "📦 Install Nginx..."
    sudo apt update
    sudo apt install -y nginx
else
    echo "✅ Nginx sudah terinstall"
fi

# Buat konfigurasi Nginx
echo "📝 Buat konfigurasi Nginx..."

sudo tee /etc/nginx/sites-available/imagehost > /dev/null <<'EOF'
server {
    listen 80;
    server_name images.azxpedia.my.id;

    access_log /var/log/nginx/imagehost-access.log;
    error_log /var/log/nginx/imagehost-error.log;

    location / {
        proxy_pass http://localhost:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeout settings
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # File upload size limit
        client_max_body_size 10M;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
EOF

echo "✅ Konfigurasi Nginx dibuat"

# ============================================
# 4.2 Aktifkan Konfigurasi
# ============================================

echo ""
echo "========================================="
echo "  4.2 Aktifkan Konfigurasi"
echo "========================================="

# Hapus default site jika ada
if [ -f /etc/nginx/sites-enabled/default ]; then
    echo "🗑️  Menghapus default site..."
    sudo rm /etc/nginx/sites-enabled/default
fi

# Aktifkan site
echo "🔗 Mengaktifkan site imagehost..."
sudo ln -sf /etc/nginx/sites-available/imagehost /etc/nginx/sites-enabled/

# Test konfigurasi
echo "🧪 Test konfigurasi Nginx..."
if sudo nginx -t; then
    echo "✅ Konfigurasi Nginx valid"
    
    # Restart Nginx
    echo "🔄 Restart Nginx..."
    sudo systemctl restart nginx
    sudo systemctl enable nginx
    echo "✅ Nginx berhasil di-restart"
else
    echo "❌ Konfigurasi Nginx error!"
    exit 1
fi

# ============================================
# 5. Setup SSL/HTTPS
# ============================================

echo ""
echo "========================================="
echo "  5. Setup SSL/HTTPS"
echo "========================================="

# ============================================
# 5.1 Install Certbot
# ============================================

echo ""
echo "========================================="
echo "  5.1 Install Certbot"
echo "========================================="

if ! command -v certbot &> /dev/null; then
    echo "📦 Install Certbot dan Nginx plugin..."
    sudo apt update
    sudo apt install -y certbot python3-certbot-nginx
    echo "✅ Certbot terinstall"
else
    echo "✅ Certbot sudah terinstall"
fi

# ============================================
# 5.2 Generate SSL Certificate
# ============================================

echo ""
echo "========================================="
echo "  5.2 Generate SSL Certificate"
echo "========================================="

echo ""
echo "📝 Masukkan email untuk SSL certificate:"
read -p "Email: " SSL_EMAIL

if [ -z "$SSL_EMAIL" ]; then
    echo "❌ Email tidak boleh kosong!"
    exit 1
fi

echo ""
echo "🚀 Generate SSL certificate untuk $DOMAIN..."
echo ""

sudo certbot --nginx \
    -d $DOMAIN \
    --non-interactive \
    --agree-tos \
    -m $SSL_EMAIL \
    --redirect

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ SSL Certificate berhasil dibuat!"
    echo "✅ HTTPS sudah aktif untuk $DOMAIN"
    
    # Auto-renewal test
    echo ""
    echo "🔄 Test auto-renewal..."
    sudo certbot renew --dry-run
    
    if [ $? -eq 0 ]; then
        echo "✅ Auto-renewal berhasil di-test"
    else
        echo "⚠️  Auto-renewal test gagal, tapi cert tetap aktif"
    fi
else
    echo "❌ Gagal membuat SSL certificate!"
    echo "Coba manual dengan:"
    echo "sudo certbot --nginx -d $DOMAIN"
    exit 1
fi

# ============================================
# Selesai
# ============================================

echo ""
echo "========================================="
echo "  ✅ SETUP SELESAI!"
echo "========================================="
echo ""
echo "🌐 Website: https://$DOMAIN"
echo "🔒 SSL aktif: ✅"
echo "🔄 Auto-renewal: ✅"
echo ""
echo "📝 Cek status:"
echo "  - Nginx: sudo systemctl status nginx"
echo "  - Certbot: sudo certbot certificates"
echo "  - Logs: sudo tail -f /var/log/nginx/imagehost-error.log"
echo ""
echo "⚠️  Pastikan Node.js server berjalan di port 4000"
echo "   Jalankan: pm2 start server.js --name imagehost"
echo ""

# ============================================
# Cek status final
# ============================================

echo "📊 Status Final:"
echo "-----------------------------------------"
echo -n "Nginx: "
sudo systemctl is-active nginx
echo -n "SSL: "
sudo certbot certificates 2>/dev/null | grep -q $DOMAIN && echo "✅ Aktif" || echo "❌ Tidak aktif"
echo "-----------------------------------------"
echo ""
echo "🎉 Selesai! Akses https://$DOMAIN"