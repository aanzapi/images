const express = require('express');
const multer = require('multer');
const { createClient } = require('@supabase/supabase-js');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = 4000;

// ==========================================
// Supabase Configuration
// ==========================================
const SUPABASE_URL = 'https://jvzracadsexthroftbel.supabase.co';
const SUPABASE_KEY = 'sb_secret_lXAIOabLpuIgiztOx-UOig_1XZR-2eg';
const SUPABASE_BUCKET = 'images';

if (!SUPABASE_URL || !SUPABASE_KEY) {
    console.error('❌ Missing SUPABASE_URL or SUPABASE_KEY in environment variables');
    process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// ==========================================
// Express Setup
// ==========================================
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ==========================================
// Multer Configuration
// ==========================================
const storage = multer.memoryStorage();
const fileFilter = (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    const allowedExtensions = ['.jpg', '.jpeg', '.png', '.webp'];
    
    const ext = path.extname(file.originalname).toLowerCase();
    const isValidType = allowedTypes.includes(file.mimetype);
    const isValidExt = allowedExtensions.includes(ext);
    
    if (isValidType && isValidExt) {
        cb(null, true);
    } else {
        cb(new Error('Only JPG, JPEG, PNG, and WEBP files are allowed'), false);
    }
};

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024 // 10MB
    },
    fileFilter: fileFilter
});

// ==========================================
// Helper Functions
// ==========================================
function generateRandomFilename(originalName) {
    const random = crypto.randomBytes(8).toString('hex');
    const ext = path.extname(originalName).toLowerCase();
    return `${random}${ext}`;
}

function getBaseUrl(req) {
    const protocol = req.get('x-forwarded-proto') || req.protocol;
    const host = req.get('host');
    return `${protocol}://${host}`;
}

// ==========================================
// Routes
// ==========================================

// Homepage
app.get('/', (req, res) => {
    res.render('index', { 
        title: 'ImageHost - Fast, Simple, Beautiful Image Hosting'
    });
});

// Serve images via custom domain
app.get('/:filename', async (req, res) => {
    try {
        const filename = req.params.filename;
        
        // Validate filename (only alphanumeric, dot, and underscore)
        if (!/^[a-zA-Z0-9._]+$/.test(filename)) {
            return res.status(400).send('Invalid filename');
        }

        // Get file from Supabase Storage
        const { data, error } = await supabase
            .storage
            .from(SUPABASE_BUCKET)
            .download(filename);

        if (error) {
            console.error('Supabase download error:', error);
            return res.status(404).send('Image not found');
        }

        // Determine content type
        const ext = path.extname(filename).toLowerCase();
        let contentType = 'image/jpeg';
        if (ext === '.png') contentType = 'image/png';
        else if (ext === '.webp') contentType = 'image/webp';
        else if (ext === '.jpg' || ext === '.jpeg') contentType = 'image/jpeg';

        res.setHeader('Content-Type', contentType);
        res.setHeader('Cache-Control', 'public, max-age=31536000');
        res.send(data);
        
    } catch (error) {
        console.error('Error serving image:', error);
        res.status(500).send('Server error');
    }
});

// Upload API
app.post('/api/upload', upload.single('image'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'No file uploaded'
            });
        }

        const file = req.file;
        const filename = generateRandomFilename(file.originalname);

        // Upload to Supabase Storage
        const { data, error } = await supabase
            .storage
            .from(SUPABASE_BUCKET)
            .upload(filename, file.buffer, {
                contentType: file.mimetype,
                cacheControl: '3600'
            });

        if (error) {
            console.error('Supabase upload error:', error);
            return res.status(500).json({
                success: false,
                message: 'Upload failed: ' + error.message
            });
        }

        // Generate URL
        const baseUrl = getBaseUrl(req);
        const imageUrl = `${baseUrl}/${filename}`;

        res.status(201).json({
            success: true,
            url: imageUrl,
            filename: filename
        });

    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({
            success: false,
            message: 'Upload failed: ' + error.message
        });
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        if (err.code === 'FILE_TOO_LARGE') {
            return res.status(400).json({
                success: false,
                message: 'File too large. Maximum size is 10MB'
            });
        }
        return res.status(400).json({
            success: false,
            message: err.message
        });
    }
    
    if (err.message && err.message.includes('Only JPG')) {
        return res.status(400).json({
            success: false,
            message: err.message
        });
    }
    
    console.error('Server error:', err);
    res.status(500).json({
        success: false,
        message: 'Internal server error'
    });
});

// ==========================================
// Start Server
// ==========================================
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📸 Image Hosting Service is ready`);
    console.log(`📦 Using Supabase bucket: ${SUPABASE_BUCKET}`);
});