const express = require('express');
const multer = require('multer');
const { createClient } = require('@supabase/supabase-js');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = 4000;

// ==========================================
// SUPABASE CONFIG
// ==========================================

const SUPABASE_URL = 'https://jvzracadsexthroftbel.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp2enJhY2Fkc2V4dGhyb2Z0YmVsIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4NjYyOTI2MywiZXhwIjoyMTAyMjA1MjYzfQ.KX5mkNYRYUzzQ3uYzxf7MxBG4PesjkwnZ9qQ5FTVk10'; // ISI DENGAN KEY ANDA

// DUA BUCKET TERPISAH
const BUCKET_IMAGES = 'images';
const BUCKET_VIDEOS = 'videos';

if (!SUPABASE_URL || !SUPABASE_KEY) {
    console.error('❌ SUPABASE_URL atau SUPABASE_KEY belum diset');
    process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// ==========================================
// EXPRESS CONFIG
// ==========================================

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Accept');
    
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});

// ==========================================
// MULTER
// ==========================================

const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
        fileSize: 100 * 1024 * 1024, // 100MB
        fieldSize: 100 * 1024 * 1024
    },
    fileFilter: (req, file, cb) => {
        const allowed = [
            // Images
            'image/jpeg', 'image/png', 'image/webp',
            // Videos
            'video/mp4', 'video/webm', 'video/quicktime'
        ];
        const exts = ['.jpg', '.jpeg', '.png', '.webp', '.mp4', '.webm', '.mov'];
        const ext = path.extname(file.originalname).toLowerCase();
        
        if (allowed.includes(file.mimetype) && exts.includes(ext)) {
            cb(null, true);
        } else {
            cb(new Error('Format tidak didukung'), false);
        }
    }
});

// ==========================================
// HELPER FUNCTIONS
// ==========================================

function generateFilename(originalName) {
    const ext = path.extname(originalName).toLowerCase();
    return crypto.randomBytes(8).toString('hex') + ext;
}

function getContentType(filename) {
    const ext = path.extname(filename).toLowerCase();
    const types = {
        '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
        '.png': 'image/png', '.webp': 'image/webp',
        '.mp4': 'video/mp4', '.webm': 'video/webm',
        '.mov': 'video/quicktime'
    };
    return types[ext] || 'application/octet-stream';
}

function getFileType(mimetype) {
    if (mimetype.startsWith('video/')) return 'video';
    if (mimetype.startsWith('image/')) return 'image';
    return 'unknown';
}

function getBucket(mimetype) {
    if (mimetype.startsWith('video/')) return BUCKET_VIDEOS;
    return BUCKET_IMAGES;
}

function getBaseUrl(req) {
    const proto = req.headers['x-forwarded-proto'] || req.protocol;
    return `${proto}://${req.get('host')}`;
}

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
}

// ==========================================
// CREATE BUCKETS (Otomatis)
// ==========================================

async function createBuckets() {
    try {
        // Create Images Bucket
        const { data: bucketImages, error: errImages } = await supabase
            .storage
            .createBucket(BUCKET_IMAGES, {
                public: true,
                allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
                fileSizeLimit: 10485760 // 10MB
            });
        
        if (errImages && !errImages.message.includes('already exists')) {
            console.error('❌ Error creating images bucket:', errImages);
        } else {
            console.log(`✅ Bucket "${BUCKET_IMAGES}" ready`);
        }

        // Create Videos Bucket
        const { data: bucketVideos, error: errVideos } = await supabase
            .storage
            .createBucket(BUCKET_VIDEOS, {
                public: true,
                allowedMimeTypes: ['video/mp4', 'video/webm', 'video/quicktime'],
                fileSizeLimit: 104857600 // 100MB
            });
        
        if (errVideos && !errVideos.message.includes('already exists')) {
            console.error('❌ Error creating videos bucket:', errVideos);
        } else {
            console.log(`✅ Bucket "${BUCKET_VIDEOS}" ready`);
        }

        // Set both buckets to public
        await supabase.storage.updateBucket(BUCKET_IMAGES, { public: true });
        await supabase.storage.updateBucket(BUCKET_VIDEOS, { public: true });

    } catch (error) {
        console.error('❌ Bucket setup error:', error);
    }
}

// ==========================================
// ROUTES
// ==========================================

app.get('/', (req, res) => {
    res.render('index', { 
        title: 'ImageHost — Brutalist Media Hosting'
    });
});

// ==========================================
// UPLOAD — Auto detect bucket
// ==========================================

app.post('/api/upload', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'No file uploaded'
            });
        }

        const file = req.file;
        const filename = generateFilename(file.originalname);
        const fileType = getFileType(file.mimetype);
        const bucket = getBucket(file.mimetype);

        console.log('');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log(`📤 Upload: ${file.originalname}`);
        console.log(`📂 Type: ${fileType}`);
        console.log(`📦 Bucket: ${bucket}`);
        console.log(`📏 Size: ${formatSize(file.size)}`);
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

        // Upload ke bucket yang sesuai
        const { data, error } = await supabase
            .storage
            .from(bucket)
            .upload(filename, file.buffer, {
                contentType: file.mimetype,
                cacheControl: '31536000'
            });

        if (error) {
            console.error('❌ Supabase error:', error);
            return res.status(500).json({
                success: false,
                message: error.message || 'Upload failed'
            });
        }

        // Generate URL dengan bucket name
        const baseUrl = getBaseUrl(req);
        const fileUrl = `${baseUrl}/${bucket}/${filename}`;

        console.log(`✅ Upload successful`);
        console.log(`🔗 URL: ${fileUrl}`);
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('');

        return res.status(201).json({
            success: true,
            url: fileUrl,
            filename: filename,
            bucket: bucket,
            type: fileType,
            mimetype: file.mimetype,
            size: file.size
        });

    } catch (error) {
        console.error('❌ Upload error:', error);
        return res.status(500).json({
            success: false,
            message: error.message || 'Upload failed'
        });
    }
});

// ==========================================
// SERVE FILE — Support multi bucket
// ==========================================

app.get('/:bucket/:filename', async (req, res) => {
    try {
        const { bucket, filename } = req.params;
        
        // Validasi bucket
        if (![BUCKET_IMAGES, BUCKET_VIDEOS].includes(bucket)) {
            return res.status(400).send('Invalid bucket');
        }

        // Validasi filename
        if (!/^[a-zA-Z0-9._-]+$/.test(filename)) {
            return res.status(400).send('Invalid filename');
        }

        console.log(`🖼️ Request: ${bucket}/${filename}`);

        // Download dari bucket yang sesuai
        const { data, error } = await supabase
            .storage
            .from(bucket)
            .download(filename);

        if (error || !data) {
            console.error('❌ Download error:', error);
            return res.status(404).send(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>404 — File Not Found</title>
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        body {
                            background: #0a0a0a;
                            color: #e0e0e0;
                            font-family: 'Courier New', monospace;
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            padding: 20px;
                        }
                        .container {
                            border: 3px solid #ff3b3b;
                            padding: 60px 80px;
                            max-width: 600px;
                            text-align: center;
                            background: #111;
                        }
                        .code { font-size: 120px; font-weight: 900; color: #ff3b3b; line-height: 1; }
                        .title { font-size: 28px; font-weight: 700; margin: 20px 0 10px; text-transform: uppercase; letter-spacing: 4px; }
                        .desc { font-size: 16px; color: #888; margin-bottom: 30px; }
                        .link {
                            display: inline-block;
                            padding: 12px 32px;
                            border: 2px solid #ff3b3b;
                            color: #ff3b3b;
                            text-decoration: none;
                            font-weight: 700;
                            text-transform: uppercase;
                            letter-spacing: 2px;
                            transition: all 0.3s;
                        }
                        .link:hover {
                            background: #ff3b3b;
                            color: #0a0a0a;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="code">404</div>
                        <div class="title">File Not Found</div>
                        <div class="desc">The file you're looking for doesn't exist or has been removed.</div>
                        <a href="/" class="link">← Return Home</a>
                    </div>
                </body>
                </html>
            `);
        }

        const buffer = Buffer.from(await data.arrayBuffer());
        const contentType = getContentType(filename);

        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Length', buffer.length);
        res.setHeader('Cache-Control', 'public, max-age=31536000');
        res.end(buffer);

    } catch (error) {
        console.error('❌ Serve error:', error);
        res.status(500).send('Server error');
    }
});

// ==========================================
// ERROR HANDLER
// ==========================================

app.use((err, req, res, next) => {
    console.error('❌ Error:', err);

    if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({
                success: false,
                message: 'File terlalu besar. Maksimum 100MB.'
            });
        }
        return res.status(400).json({
            success: false,
            message: err.message
        });
    }

    res.status(500).json({
        success: false,
        message: err.message || 'Internal server error'
    });
});

// ==========================================
// START
// ==========================================

createBuckets().then(() => {
    const server = app.listen(PORT, '0.0.0.0', () => {
        console.log('');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('  🚀 IMAGEHOST — BRUTALIST');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log(`  🌐 Port: ${PORT}`);
        console.log(`  📁 Images Bucket: ${BUCKET_IMAGES}`);
        console.log(`  🎬 Videos Bucket: ${BUCKET_VIDEOS}`);
        console.log(`  📏 Max Size: 100MB`);
        console.log('  🟢 Server is ready');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('');
    });
    
    server.timeout = 300000; // 5 menit
});